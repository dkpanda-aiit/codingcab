package com.isl.empapi;

import com.isl.model.Employee;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
@RequestMapping ( "/EmpService" )
public class EmployeeRestController {

    HashMap <String, Employee> empMap = new HashMap <> ();

    /* example of path param as request */
    @GetMapping ( "{id}" )
    public Employee getEmployee ( @PathVariable String id ) {
        System.out.println ( "Input Request : " + id );
        Employee emp = empMap.get ( id );
        return emp;
    }

    /* example of query param as request */
    @GetMapping
    public Employee getEmployeeDtls ( @RequestParam ( value = "id", required = false ) String id ) {
        System.out.println ( "Input Request : " + id );
        Employee emp = empMap.get ( id );
        return emp;
    }

    /* example of Post mapping for adding data as Request Body */
    @PostMapping
    public String addEmployee ( @RequestBody Employee input ) {
        System.out.println ( "Input Request : " + input.id + ", " + input.name + ", " + input.desig );
        empMap.put ( input.getId (), input );
        System.out.println ( empMap );
        return "Employee ID " + input.getId () + " data added Successfully";

    }
}
