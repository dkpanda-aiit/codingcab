package com.isl.empapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpapiApplication.class, args);
	}

}
