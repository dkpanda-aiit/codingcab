package com.isl.empapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
